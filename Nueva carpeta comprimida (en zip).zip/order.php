<?php
// Definición de constantes para la URL de la API y la clave de la API
const shipment_data = "https://api.adcombo.com/api/v2/order/create/";

// Construcción de los argumentos para la solicitud a la API
$args = [
    'api_key' => 'ecfe7c02ea5ec54327b1060537cb5e7b',
    'name' => $_POST['name'],
    'phone' => $_POST['phone'],
    'offer_id' => $_POST['offer_id'],
    'country_code' => $_POST['country_code'],
    'price' => $_POST['price'],
    'base_url' => 'https://saludable.saludable.com',
    'ip' => $_SERVER['REMOTE_ADDR'],
    'referrer' => $_SERVER["HTTP_REFERER"],
];

// Construcción de la URL completa con los argumentos
$url = shipment_data.'?'.http_build_query($args);

// Inicialización de la sesión cURL
$curl = curl_init();

// Configuración de las opciones de la sesión cURL
curl_setopt_array($curl, array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true
));

// Ejecución de la solicitud cURL y obtención de la respuesta
$res = curl_exec($curl);

// Cierre de la sesión cURL
curl_close($curl);

// Decodificación de la respuesta JSON
$res = json_decode($res, true);

// Verificación del código de la respuesta de la API
if ($res['code'] == 'ok') {
    // Redireccionamiento a la página 'confirmed.php' con parámetros y muestra del mensaje y ID del pedido
    header('Location: confirmed.php?name='.$_POST['name'].'&phone='.$_POST['phone'].'&referrer='.$_SERVER["HTTP_REFERER"]);
    echo $res['msg'] . ": " . $res['order_id'];
} else {
    // En caso de error, muestra un mensaje de error
    echo "Error: " . $sql . "<br>" . $conn->error;
}
// Cierre de la conexión (que parece estar fuera de lugar y no es necesaria en este contexto)
$conn->close();

?>
