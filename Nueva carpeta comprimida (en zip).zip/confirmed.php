<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmado</title>
    <style>
      body {
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f8f9fa;
}

.content {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.wrapper-1 {
    background-color: #ffffff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    text-align: center;
}

.wrapper-2 {
    margin-top: 20px;
}

h1 {
    color: #007bff;
}

img {
    margin-top: 10px;
}

h5 {
    color: #6c757d;
}

p {
    margin: 10px 0;
}

.btn {
    text-decoration: none;
    color: #007bff;
    cursor: pointer;
    font-weight: bold;
}

.btn:hover {
    text-decoration: underline;
}

    </style>
</head>
<body>
    <div class=content>
        <div class="wrapper-1">
          <div class="wrapper-2">
            <h1 class="fst-italic">Gracias por tu pedido</h1>
            <img width="100px" src="https://e36ewfi8yx4.exactdn.com/wp-content/uploads/2019/10/atencion-telefonica.gif?strip=all&lossy=1&w=2560&ssl=1" alt="" srcset="">
            <br>
            <h5>Verifique sus datos</h5>
            <p class="fw-bold fst-italic">NOMBRE: <span class="fw-normal fst-italic"> <?php echo $_GET['name']; ?></span></p>
            <P class="fw-bold fst-italic">TELEFONO: <span class="fw-normal fst-italic"> <?php echo $_GET['phone']; ?></span></P>
            <br>
            <p class="fst-italic">Si es correcto, enseguida le llamaremos para Confirmar tu Pedido </p>
            <img width="150px" src="img/gif-llamada.gif" alt="" srcset="">
            <p class="fst-italic">Si cometio error al rellenar sus datos, vuelva a rellenar </p>
            <a type="button" class="btn btn-link fs-5" href="<?php echo parse_url($_GET['referrer'], PHP_URL_SCHEME) . '://' . parse_url($_GET['referrer'], PHP_URL_HOST) . parse_url($_GET['referrer'], PHP_URL_PATH); ?>">←Volver a Rellenar📝</a>
          </div>
      </div>
      </div>
<br>
<br>
</body>
</html>